
export default function Dashboard() {
  return (
    <div>
      <h1>Bienvenido</h1>
    </div>
  );
}
