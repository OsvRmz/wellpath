export default function Home() {
  return <h1>Bienvenido a wellpath</h1>;
}
