// src/api/habito.js
import client from "./client";

/**
 * GET /api/habitos
 * response -> [ { _id, usuarioId, nombre, descripcion, ... } ]
 */
export const getHabitos = async () => {
  try {
    const res = await client.get("/api/habitos");
    return res.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || error.message);
  }
};

/**
 * POST /api/habitos
 * body: { nombre, descripcion, frecuencia, meta, recordatorio, activo }
 */
export const crearHabito = async (payload) => {
  try {
    const res = await client.post("/api/habitos", payload);
    return res.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || error.message);
  }
};

/**
 * PUT /api/habitos/:id
 */
export const actualizarHabito = async (id, updates) => {
  try {
    const res = await client.put(`/api/habitos/${id}`, updates);
    return res.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || error.message);
  }
};

/**
 * DELETE /api/habitos/:id  (en tu backend desactiva)
 */
export const eliminarHabito = async (id) => {
  try {
    const res = await client.delete(`/api/habitos/${id}`);
    return res.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || error.message);
  }
};
