export default function Historial(){
    return (
        <h1>Historial</h1>
    )
}