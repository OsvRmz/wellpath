// src/api/usuario.js
import client from "./client";

/**
 * GET /api/perfil
 * response -> { nombre, correo, racha, fechaRegistro }
 */
export const getPerfil = async () => {
  try {
    const res = await client.get("/api/perfil");
    return res.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || error.message);
  }
};

/**
 * PUT /api/perfil
 * body: { nombre?, correo?, contraseña? }
 * response -> usuario actualizado
 */
export const updatePerfil = async (updates) => {
  try {
    const res = await client.put("/api/perfil", updates);
    return res.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || error.message);
  }
};
