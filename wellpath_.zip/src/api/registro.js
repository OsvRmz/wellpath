// src/api/registro.js
import client from "./client";

/**
 * POST /api/registros
 * body: { habitoId, fecha? }  
 */
export const toggleRegistro = async ({ habitoId, fecha }) => {
  try {
    const res = await client.post("/api/registros", { habitoId, fecha });
    return res.data; // devuelve el registro actualizado/creado
  } catch (error) {
    throw new Error(error.response?.data?.message || error.message);
  }
};

/**
 * GET /api/registros/mes?year=YYYY&month=M
 * month: 1..12
 * response -> [ { habitoId, nombre, dias: [{day, completado}] }, ... ]
 */
export const getRegistrosDelMes = async ({ year, month } = {}) => {
  try {
    const params = {};
    if (year) params.year = year;
    if (month) params.month = month;
    const res = await client.get("/api/registros/mes", { params });
    return res.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || error.message);
  }
};
