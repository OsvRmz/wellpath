import express from "express";
import jwt from "jsonwebtoken";
import cors from "cors";
import path from "path";
import morgan from "morgan";
import mongoose from "mongoose";
import dotenv from "dotenv";

import Usuario from "./user.js";   // modelo Usuario (nombre, correo, contraseña, racha, fechaRegistro)
import Habito from "./habito.js";  // modelo Habito (usuarioId, nombre, descripcion, frecuencia, meta, recordatorio, activo)
import Registro from "./registro.js"; // modelo Registro (usuarioId, habitoId, fecha, completado)

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(morgan("dev"));

const PORT = process.env.PORT || 3000;
const SECRET = process.env.JWT_SECRET || "cambiame";
const __dirname = path.resolve();

// --- Conexión a MongoDB ---
mongoose.set('strictQuery', false);
mongoose
  .connect(process.env.MONGODB_URI)
  .then(() => console.log("Conectado a MongoDB"))
  .catch((err) => console.error("Error al conectar con MongoDB:", err));

// --- Servir imágenes públicas ---
app.use("/public", express.static(path.join(__dirname, "public")));

// --- Servir archivos estáticos de React ---
app.use(express.static(path.join(__dirname, "dist")));

/**
 * POST /auth/signup
 * body: { nombre, correo, contraseña }
 */
app.post("/auth/signup", async (req, res) => {
  try {
    const { nombre, correo, contraseña } = req.body;
    console.log(nombre,correo,contraseña)
    if (!nombre || !correo || !contraseña)
      return res.status(400).json({ message: "Todos los campos son obligatorios" });

    const exists = await Usuario.findOne({ correo });
    if (exists) return res.status(400).json({ message: "El usuario ya existe" });

    const newUser = new Usuario({
      nombre,
      correo,
      contraseña, 
      racha: 0
    });
    await newUser.save();

    return res.status(201).json({ message: "Usuario registrado con éxito" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error interno" });
  }
});

/**
 * POST /auth/login
 * body: { correo, contraseña }
 * response: { token, usuario: { id, nombre, correo, racha } }
 */
app.post("/auth/login", async (req, res) => {
  try {
    const { correo, contraseña } = req.body;
    console.log(correo,contraseña)
    if (!correo || !contraseña)
      return res.status(400).json({ message: "Correo y contraseña son requeridos" });

    const user = await Usuario.findOne({ correo });
    if (!user || user.contraseña !== contraseña)
      return res.status(400).json({ message: "Credenciales inválidas" });

    const token = jwt.sign(
      { id: user._id.toString(), nombre: user.nombre, correo: user.correo },
      SECRET,
      { expiresIn: "2h" }
    );

    res.json({
      token,
      usuario: {
        id: user._id,
        nombre: user.nombre,
        correo: user.correo,
        racha: user.racha || 0
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error interno" });
  }
});

/**
 * Middleware de autenticación
 * Espera header: Authorization: Bearer <token>
 */
function authMiddleware(req, res, next) {
  const header = req.headers["authorization"];
  if (!header) return res.status(401).json({ message: "Token requerido" });

  const parts = header.split(" ");
  if (parts.length !== 2 || parts[0] !== "Bearer") {
    return res.status(401).json({ message: "Formato de token inválido" });
  }

  const token = parts[1];

  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) return res.status(403).json({ message: "Token inválido o expirado" });
    req.user = decoded; // { id, nombre, correo }
    next();
  });
}

/**
 * Helpers de fecha: inicio y fin del día
 */
function startOfDay(date) {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
}
function endOfDay(date) {
  const d = new Date(date);
  d.setHours(23, 59, 59, 999);
  return d;
}

/* ============================
   RUTAS PROTEGIDAS (API principal)
   ============================ */

/**
 * GET /dashboard
 * Devuelve resumen del día:
 * { totalHabitos, habitosCompletadosHoy, porcentaje, habitosRestantes: [habitos], racha, mensaje }
 */
app.get("/api/dashboard", authMiddleware, async (req, res) => {
  try {
    const usuarioId = req.user.id;

    // contar hábitos activos del usuario
    const totalHabitos = await Habito.countDocuments({ usuarioId, activo: true });

    // buscar registros completados hoy
    const hoyInicio = startOfDay(new Date());
    const hoyFin = endOfDay(new Date());

    const habitosCompletadosHoy = await Registro.countDocuments({
      usuarioId,
      fecha: { $gte: hoyInicio, $lte: hoyFin },
      completado: true
    });

    const porcentaje = totalHabitos === 0 ? 0 : Math.round((habitosCompletadosHoy / totalHabitos) * 100);

    // obtener hábitos restantes (nombres y _id)
    const habitosCompletadosHoyDocs = await Registro.find({
      usuarioId,
      fecha: { $gte: hoyInicio, $lte: hoyFin },
      completado: true
    }).select("habitoId -_id");

    const habitosCompletadosIds = habitosCompletadosHoyDocs.map(r => r.habitoId.toString());

    const habitosRestantes = await Habito.find({
      usuarioId,
      activo: true,
      _id: { $nin: habitosCompletadosIds }
    }).select("nombre descripcion");

    const usuario = await Usuario.findById(usuarioId).select("racha nombre");

    let mensaje = "";
    if (porcentaje >= 80) mensaje = "¡Excelente trabajo! Sigue así.";
    else if (porcentaje >= 50) mensaje = "Vas por buen camino. ¡No te rindas!";
    else if (porcentaje > 0) mensaje = "Buen comienzo, intenta mejorar un poco más.";
    else mensaje = "Hoy aún no registras hábitos. ¡Empieza por uno pequeño!";

    res.json({
      totalHabitos,
      habitosCompletadosHoy,
      porcentaje,
      habitosRestantes,
      racha: usuario?.racha || 0,
      nombre: usuario?.nombre || "",
      mensaje
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error al obtener dashboard" });
  }
});

/**
 * HABITOS
 * GET /api/habitos            -> lista los hábitos del usuario
 * POST /api/habitos           -> crear hábito
 * PUT /api/habitos/:id        -> actualizar hábito
 * DELETE /api/habitos/:id     -> desactivar/eliminar hábito
 */

app.get("/api/habitos", authMiddleware, async (req, res) => {
  try {
    const usuarioId = req.user.id;
    const habitos = await Habito.find({ usuarioId });
    res.json(habitos);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error al obtener hábitos" });
  }
});

app.post("/api/habitos", authMiddleware, async (req, res) => {
  try {
    const usuarioId = req.user.id;
    const { nombre, descripcion, frecuencia = "diario", meta = "", recordatorio = "", activo = true } = req.body;

    if (!nombre) return res.status(400).json({ message: "El nombre del hábito es obligatorio" });

    const nuevo = new Habito({
      usuarioId,
      nombre,
      descripcion,
      frecuencia,
      meta,
      recordatorio,
      activo
    });

    await nuevo.save();
    res.status(201).json(nuevo);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error al crear hábito" });
  }
});

app.put("/api/habitos/:id", authMiddleware, async (req, res) => {
  try {
    const usuarioId = req.user.id;
    const { id } = req.params;
    const updates = req.body;

    const habito = await Habito.findOneAndUpdate({ _id: id, usuarioId }, updates, { new: true });
    if (!habito) return res.status(404).json({ message: "Hábito no encontrado" });

    res.json(habito);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error al actualizar hábito" });
  }
});

app.delete("/api/habitos/:id", authMiddleware, async (req, res) => {
  try {
    const usuarioId = req.user.id;
    const { id } = req.params;

    const habito = await Habito.findOneAndUpdate({ _id: id, usuarioId }, { activo: false }, { new: true });
    if (!habito) return res.status(404).json({ message: "Hábito no encontrado" });

    res.json({ message: "Hábito desactivado", habito });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error al eliminar hábito" });
  }
});

/**
 * REGISTROS
 * POST /api/registros
 * body: { habitoId, fecha (opcional, YYYY-MM-DD) }
 * Si ya existe un registro para esa fecha+habito -> actualiza completado (toggle)
 * Si no existe -> crea uno con completado: true
 */
app.post("/api/registros", authMiddleware, async (req, res) => {
  try {
    const usuarioId = req.user.id;
    const { habitoId, fecha } = req.body;

    if (!habitoId) return res.status(400).json({ message: "habitoId es requerido" });

    const fechaObj = fecha ? new Date(fecha) : new Date();
    const inicio = startOfDay(fechaObj);
    const fin = endOfDay(fechaObj);

    let registro = await Registro.findOne({
      usuarioId,
      habitoId,
      fecha: { $gte: inicio, $lte: fin }
    });

    if (registro) {
      registro.completado = !registro.completado;
      await registro.save();
    } else {
      registro = new Registro({
        usuarioId,
        habitoId,
        fecha: fechaObj,
        completado: true
      });
      await registro.save();
    }

    const hoyInicio = startOfDay(new Date());
    const hoyFin = endOfDay(new Date());
    const totalHabitos = await Habito.countDocuments({ usuarioId, activo: true });
    const completadosHoy = await Registro.distinct("habitoId", {
      usuarioId,
      fecha: { $gte: hoyInicio, $lte: hoyFin },
      completado: true
    });

    if (totalHabitos > 0 && completadosHoy.length === totalHabitos) {
      await Usuario.findByIdAndUpdate(usuarioId, { $inc: { racha: 1 } });
    } else {
    }

    res.json(registro);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error al crear/actualizar registro" });
  }
});

/**
 * GET /api/registros/mes?year=2025&month=10
 * Devuelve para cada hábito del usuario un array con los días del mes y si están completados.
 * Response:
 * [
 *  { habitoId, nombre, dias: [{ day: 1, completado: true }, ... ] },
 *  ...
 * ]
 */
app.get("/api/registros/mes", authMiddleware, async (req, res) => {
  try {
    const usuarioId = req.user.id;
    const year = parseInt(req.query.year) || new Date().getFullYear();
    const month = parseInt(req.query.month) || (new Date().getMonth() + 1);

    const inicioMes = new Date(year, month - 1, 1);
    const finMes = new Date(year, month, 0, 23, 59, 59, 999);

    const habitos = await Habito.find({ usuarioId, activo: true });

    const registrosMes = await Registro.find({
      usuarioId,
      fecha: { $gte: startOfDay(inicioMes), $lte: endOfDay(finMes) },
      completado: true
    });

    const resultado = habitos.map(h => {
      // días del mes (1..n)
      const diasDelMes = finMes.getDate();
      const dias = [];
      for (let d = 1; d <= diasDelMes; d++) {
        dias.push({ day: d, completado: false });
      }

      const registrosDelHabito = registrosMes.filter(r => r.habitoId.toString() === h._id.toString());
      registrosDelHabito.forEach(r => {
        const dia = new Date(r.fecha).getDate();
        dias[dia - 1].completado = true;
      });

      return {
        habitoId: h._id,
        nombre: h.nombre,
        dias
      };
    });

    res.json(resultado);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error al obtener registros del mes" });
  }
});

/**
 * ESTADÍSTICAS
 * GET /api/stats?range=monthly|weekly
 * Response minimal: { porHabit: [{ habitoId, nombre, totalCompletados, diasRegistrados, porcentaje }], totalPorcentaje }
 */
app.get("/api/stats", authMiddleware, async (req, res) => {
  try {
    const usuarioId = req.user.id;
    const range = req.query.range || "monthly";

    let inicio;
    const hoy = new Date();
    if (range === "weekly") {
      // últimos 7 días
      inicio = new Date();
      inicio.setDate(hoy.getDate() - 6); // 7 días incluyendo hoy
      inicio.setHours(0, 0, 0, 0);
    } else {
      // monthly por defecto -> inicio del mes
      inicio = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
    }

    const fin = endOfDay(hoy);

    const habitos = await Habito.find({ usuarioId, activo: true });

    // para cada hábito calculamos completados y porcentaje (sobre número de días del periodo)
    const diasPeriodo = Math.ceil((fin - startOfDay(inicio)) / (1000 * 60 * 60 * 24)) + 1;
    const statsPorHabito = await Promise.all(habitos.map(async (h) => {
      const totalCompletados = await Registro.countDocuments({
        usuarioId,
        habitoId: h._id,
        fecha: { $gte: startOfDay(inicio), $lte: fin },
        completado: true
      });
      const porcentaje = Math.round((totalCompletados / diasPeriodo) * 100);
      return {
        habitoId: h._id,
        nombre: h.nombre,
        totalCompletados,
        diasPeriodo,
        porcentaje
      };
    }));

    // porcentaje general: promedio simple
    const totalPorcentaje = statsPorHabito.length === 0
      ? 0
      : Math.round(statsPorHabito.reduce((s, x) => s + x.porcentaje, 0) / statsPorHabito.length);

    res.json({ porHabito: statsPorHabito, totalPorcentaje });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error al calcular estadísticas" });
  }
});

/**
 * HISTORIAL (lista de días con % hábitos completados)
 * GET /api/historial?days=14  -> últimos N días (por defecto 14)
 * Response: [{ fecha: '2025-10-20', porcentaje: 80 }, ...]
 */
app.get("/api/historial", authMiddleware, async (req, res) => {
  try {
    const usuarioId = req.user.id;
    const days = parseInt(req.query.days) || 14;

    const hoy = new Date();
    const inicio = startOfDay(new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate() - (days - 1)));

    const totalHabitos = await Habito.countDocuments({ usuarioId, activo: true });

    const listado = [];
    for (let i = 0; i < days; i++) {
      const fecha = new Date(inicio);
      fecha.setDate(inicio.getDate() + i);
      const inicioD = startOfDay(fecha);
      const finD = endOfDay(fecha);

      const completados = await Registro.distinct("habitoId", {
        usuarioId,
        fecha: { $gte: inicioD, $lte: finD },
        completado: true
      });

      const porcentaje = totalHabitos === 0 ? 0 : Math.round((completados.length / totalHabitos) * 100);
      listado.push({ fecha: inicioD.toISOString().slice(0, 10), porcentaje });
    }

    res.json(listado);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error al obtener historial" });
  }
});

/**
 * PERFIL
 * GET /api/perfil
 * PUT /api/perfil  { nombre, correo, contraseña }
 */
app.get("/api/perfil", authMiddleware, async (req, res) => {
  try {
    const usuarioId = req.user.id;
    const usuario = await Usuario.findById(usuarioId).select("nombre correo racha fechaRegistro");
    if (!usuario) return res.status(404).json({ message: "Usuario no encontrado" });
    res.json(usuario);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error al obtener perfil" });
  }
});

app.put("/api/perfil", authMiddleware, async (req, res) => {
  try {
    const usuarioId = req.user.id;
    const updates = {};
    const { nombre, correo, contraseña } = req.body;
    if (nombre) updates.nombre = nombre;
    if (correo) updates.correo = correo;
    if (contraseña) updates.contraseña = contraseña; 

    const usuario = await Usuario.findByIdAndUpdate(usuarioId, updates, { new: true }).select("nombre correo racha fechaRegistro");
    res.json(usuario);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error al actualizar perfil" });
  }
});

app.get(/.*/, (req, res) => {
  res.sendFile(path.join(__dirname, "dist", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
