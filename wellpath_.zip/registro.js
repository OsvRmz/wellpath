import mongoose from "mongoose";

const registroSchema = new mongoose.Schema({
  usuarioId: { type: mongoose.Schema.Types.ObjectId, ref: "Usuario", required: true },
  habitoId: { type: mongoose.Schema.Types.ObjectId, ref: "Habito", required: true },
  fecha: { type: Date, required: true },
  completado: { type: Boolean, default: false }
});

export default mongoose.model("Registro", registroSchema);
