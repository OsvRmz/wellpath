// src/api/dashboard.js
import client from "./client";

/**
 * GET /api/dashboard
 * response -> { totalHabitos, habitosCompletadosHoy, porcentaje, habitosRestantes, racha, nombre, mensaje }
 */
export const getDashboard = async () => {
  try {
    const res = await client.get("/api/dashboard");
    return res.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || error.message);
  }
};

/**
 * GET /api/stats?range=monthly|weekly
 * response -> { porHabito: [...], totalPorcentaje }
 */
export const getStats = async (range = "monthly") => {
  try {
    const res = await client.get("/api/stats", { params: { range }});
    return res.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || error.message);
  }
};

/**
 * GET /api/historial?days=N
 * response -> [ { fecha: 'YYYY-MM-DD', porcentaje } ]
 */
export const getHistorial = async (days = 14) => {
  try {
    const res = await client.get("/api/historial", { params: { days }});
    return res.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || error.message);
  }
};
