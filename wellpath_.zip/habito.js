import mongoose from "mongoose";

const habitoSchema = new mongoose.Schema({
  usuarioId: { type: mongoose.Schema.Types.ObjectId, ref: "Usuario", required: true },
  nombre: { type: String, required: true },
  descripcion: String,
  frecuencia: { type: String, default: "diario" }, 
  meta: String, 
  recordatorio: String, 
  activo: { type: Boolean, default: true },
  fechaCreacion: { type: Date, default: Date.now }
});

export default mongoose.model("Habito", habitoSchema);
