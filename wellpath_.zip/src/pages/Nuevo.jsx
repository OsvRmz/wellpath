// src/pages/Nuevo.jsx
import { useState, useEffect } from "react";
import Loading from "../components/Loading";
import { crearHabito } from "../api/habito";


export default function Nuevo() {
  const [nombre, setNombre] = useState("");
  const [descripcion, setDescripcion] = useState("");
  const [frecuencia, setFrecuencia] = useState("diario");
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 500);
    return () => clearTimeout(timer);
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!nombre.trim()) {
      alert("Por favor, escribe un nombre para el hábito");
      return;
    }

    const nuevoHabito = { nombre, descripcion, frecuencia };

    try {
      setIsSubmitting(true);
      await crearHabito(nuevoHabito);
      alert("Hábito agregado correctamente");
      setNombre("");
      setDescripcion("");
      setFrecuencia("diario");
    } catch (error) {
      console.error(error);
      alert("No se pudo agregar el hábito: " + error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) return <Loading />;

  return (
    <div className="w-full min-h-0 bg-[#F7F2EC] flex justify-center items-start p-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 w-full max-w-5xl">
        {/* Formulario para crear hábito */}
        <div className="bg-[#FAFAA5] rounded-2xl shadow-xl shadow-gray-700/40 p-8">
          <h2 className="text-2xl font-semibold mb-6 text-gray-800">Añadir nuevo hábito</h2>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-gray-700 font-medium mb-2">Nombre</label>
              <input
                type="text"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                placeholder="Ej. Leer 10 minutos"
                className="w-full p-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-gray-700 font-medium mb-2">Descripción</label>
              <textarea
                value={descripcion}
                onChange={(e) => setDescripcion(e.target.value)}
                placeholder="Detalles o propósito del hábito..."
                className="w-full p-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                rows="3"
              ></textarea>
            </div>

            <div>
              <label className="block text-gray-700 font-medium mb-2">Frecuencia</label>
              <select
                value={frecuencia}
                onChange={(e) => setFrecuencia(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="diario">Diario</option>
                <option value="semanal">Semanal</option>
                <option value="mensual">Mensual</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className={`w-full text-white font-medium py-3 rounded-xl transition-all duration-300 ${isSubmitting ? "bg-indigo-400 cursor-not-allowed" : "bg-indigo-600 hover:bg-indigo-700"
                }`}
            >
              {isSubmitting ? "Guardando..." : "Guardar hábito"}
            </button>
          </form>
        </div>

        {/* Vista previa del hábito */}
        <div className="bg-[#FAFAA5] rounded-2xl shadow-xl shadow-gray-700/40 p-8 flex flex-col justify-center">
          <h2 className="text-2xl font-semibold mb-4 text-gray-800">Vista previa</h2>
          {nombre ? (
            <div className="p-4 border-l-4 border-indigo-500 bg-gray-50 rounded-lg">
              <h3 className="text-xl font-semibold text-gray-800">{nombre}</h3>
              <p className="text-gray-600 mt-2">{descripcion || "Sin descripción"}</p>
              <span className="text-sm mt-3 text-gray-500">Frecuencia: {frecuencia}</span>
            </div>
          ) : (
            <p className="text-gray-400 italic">Escribe un hábito para ver la vista previa aquí.</p>
          )}
        </div>
      </div>
    </div>
  );
}
