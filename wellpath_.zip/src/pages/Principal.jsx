import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getDashboard } from "../api/dashboard";
import Loading from "../components/Loading";

export default function Principal() {
  const navigate = useNavigate();

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    getDashboard()
      .then((res) => {
        if (!mounted) return;
        setData(res);
        setError(null);
      })
      .catch((err) => {
        if (!mounted) return;
        setError(err.message || "Error al cargar datos");
      })
      .finally(() => {
        if (!mounted) return;
        setLoading(false);
      });
    return () => {
      mounted = false;
    };
  }, []);

  function Donut({ percentage = 0, size = 180, stroke = 16 }) {
    const radius = (size - stroke) / 2;
    const circumference = 2 * Math.PI * radius;
    const clamped = Math.max(0, Math.min(100, Math.round(percentage)));
    const offset = circumference - (clamped / 100) * circumference;

    return (
      <div className="flex items-center justify-center">
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
          <defs>
            <linearGradient id="donutGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#7E5E48" />
              <stop offset="100%" stopColor="#C69C79" />
            </linearGradient>
          </defs>

          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="#eee"
            strokeWidth={stroke}
            fill="none"
          />

          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="url(#donutGrad)"
            strokeWidth={stroke}
            strokeLinecap="round"
            strokeDasharray={`${circumference} ${circumference}`}
            strokeDashoffset={offset}
            transform={`rotate(-90 ${size / 2} ${size / 2})`}
            fill="none"
          />

          <text
            x="50%"
            y="50%"
            dominantBaseline="middle"
            textAnchor="middle"
            className="text-gray-800"
            style={{ fontSize: size * 0.16, fontWeight: 700 }}
          >
            {clamped}%
          </text>
        </svg>
      </div>
    );
  }

  if (loading) return <Loading />;

  if (error) {
    return (
      <div className="min-h-screen bg-[#F7F2EC] flex items-center justify-center">
        <div className="text-red-600 bg-red-50 border border-red-100 p-4 rounded">
          Error: {error}
        </div>
      </div>
    );
  }

  return (
    <div className="h-full w-full bg-[#F7F2EC] box-border">
      <div className="grid grid-cols-[280px_1fr] gap-6 h-full">
        <aside className="space-y-4 overflow-y-auto">
          <div className="bg-[#FBCEE9] rounded-lg border border-gray-200 p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-700 mb-2">
              Hábitos pendientes
            </h3>
            <ul className="space-y-1 text-gray-700 text-sm">
              {Array.isArray(data.habitosRestantes) && data.habitosRestantes.length > 0 ? (
                data.habitosRestantes.map((h, idx) => (
                  <li key={idx} className="px-2 py-1 bg-[#FBCEE9] rounded border border-gray-100">
                    {h.nombre || h}
                  </li>
                ))
              ) : (
                <li className="text-gray-400">No hay hábitos pendientes</li>
              )}
            </ul>
          </div>

          <div className="bg-[#FBCEE9] rounded-lg border border-gray-200 p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-700 mb-2">Calendario</h3>
            <div className="text-sm text-gray-600">
              <div className="font-medium">{new Date().toLocaleDateString()}</div>
              <div className="text-xs text-gray-500 mt-1">Toca para ver calendario</div>
            </div>
          </div>
        </aside>

        <main className="space-y-6 overflow-y-auto">
          <div className="bg-[#FBCEE9] rounded-lg border border-gray-200 p-4 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold text-gray-800">
                  Hola{data.nombre ? `, ${data.nombre}` : ""} 
                </h2>
                <p className="text-sm text-gray-600 mt-1">
                  Has completado{" "}
                  <span className="font-semibold text-gray-800">
                    {data.habitosCompletadosHoy ?? 0}
                  </span>{" "}
                  hábitos hoy.
                </p>
              </div>
              <button
                onClick={() => navigate("/dashboard/habitos")}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-md shadow"
              >
                Ir al Habit Tracker
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="bg-[#FBCEE9] rounded-lg border border-gray-200 p-6 shadow-sm flex items-center justify-center">
              <div className="w-full max-w-xs">
                <h3 className="text-sm font-semibold text-gray-700 mb-4 text-center">
                  Progreso general
                </h3>
                <Donut percentage={data.porcentaje ?? 0} />
                <p className="text-center text-xs text-gray-500 mt-3">
                  Porcentaje total de avance hoy
                </p>
              </div>
            </div>

            <div className="flex flex-col gap-4">
              <div className="bg-[#FBCEE9] rounded-lg border border-gray-200 p-4 shadow-sm flex-1 flex flex-col justify-center">
                <h4 className="text-sm font-semibold text-gray-700">Racha</h4>
                <div className="mt-3 flex items-baseline gap-3">
                  <div className="text-3xl font-bold text-amber-600">
                    {data.racha ?? 0}
                  </div>
                  <div className="text-sm text-gray-600">días consecutivos</div>
                </div>
                <div className="mt-3 text-xs text-gray-500">
                  Sigue así para reforzar el hábito 
                </div>
              </div>

              <div className="bg-[#FBCEE9] rounded-lg border border-gray-200 p-4 shadow-sm flex-1">
                <h4 className="text-sm font-semibold text-gray-700">Retroalimentación</h4>
                <p className="mt-2 text-sm text-gray-600">
                  {data.mensaje ?? "Buen trabajo — mantén la consistencia para ver progresos."}
                </p>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
