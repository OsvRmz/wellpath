import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  correo: { type: String, required: true, unique: false },
  contraseña: { type: String, required: true },
  racha: { type: Number, default: 0 },
  fechaRegistro: { type: Date, default: Date.now }
});

export default mongoose.model("User", userSchema);
