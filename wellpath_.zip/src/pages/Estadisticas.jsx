export default function Estadisticas(){
    return (
        <h1>Estadisticas</h1>
    )
}