// src/api/auth.js
import client from "./client";

/**
 * credentials -> { correo, contraseña }
 * respuesta -> { token, usuario }
 */
export const loginUser = async (credentials) => {
  try {
    const res = await client.post("/auth/login", credentials);
    return res.data;
  } catch (error) {
    const msg = error.response?.data?.message || error.message;
    throw new Error(msg);
  }
};

/**
 * credentials -> { nombre, correo, contraseña }
 * respuesta -> { message }
 */
export const signupUser = async (credentials) => {
  try {
    const res = await client.post("/auth/signup", credentials);
    return res.data;
  } catch (error) {
    const msg = error.response?.data?.message || error.message;
    throw new Error(msg);
  }
};


