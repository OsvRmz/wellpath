export default function Perfil(){
    return (
        <h1>Perfil</h1>
    )
}